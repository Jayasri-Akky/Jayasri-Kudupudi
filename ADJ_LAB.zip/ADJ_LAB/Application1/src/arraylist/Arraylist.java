package arraylist;
import java.util.*;  
public class Arraylist { 
public static void main(String args[]){  
 ArrayList<String> list=new ArrayList<String>();//Creating arraylist    
     list.add("Mango");//Adding object in ArrayList    
     list.add("Apple");    
     list.add("Banana");    
     list.add("Grapes");    
     //Printing the arraylist object   
     System.out.println(list);  
}  
}